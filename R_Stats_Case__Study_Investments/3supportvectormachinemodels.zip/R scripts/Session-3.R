###################################################
### Support Vector Machines
###################################################

# load previous libraries
library("DMwR")
library("xts")
library("tseries")
library("quantmod")

# Support vector machines (SVMs) are modeling
# tools that can be applied to both regression 
# and classification tasks. 

# In R we have several implementations of
# SVMs including those in the package kernlab.

# The basic idea behind SVMs is that of mapping the 
# original data into a new, high-dimensional space, 
# where it is possible to apply linear models to 
# obtain a separating hyper plane, for example,
# separating the classes of the problem (classi-
# fication task). 

# The mapping of the original data into this new 
# space is carried out with the help of the 
# so-called kernel functions.

# The hyper plane separation in the new representation 
# is frequently done by maximizing a separation margin 
# between cases belonging to different classes.

# So-called "Soft margin methods" allow for a small 
# proportion of cases to be on the "wrong" side of 
# the margin, each of these leading to a known "cost". 

# We use a variant of this known as "vector regression"
# ...for our regression task we use svm() function 
# in package e1071:

library(e1071)
# use svm() with most of defaults except gamma and cost. 
# svm() uses a radial basis kernel function gamma is user
# parameter for margin error set to 1/ncol (0.001) which 
# has a hypothetical cost of 100. Here we are modeling
# trading signals with regression:
sv <- svm(Tform,Tdata.train[1:1000,],gamma=0.001,cost=100)

# take a look at sv
sv

# predict signals (continuous) from the training data:
s.preds <- predict(sv,Tdata.train[1001:2000,])
# get predicted trading signals (b, s, h):
sigs.svm <- trading.signals(s.preds,0.1,-0.1)
# get actual
true.sigs <- trading.signals(Tdata.train[1001:2000,'T.ind.GSPC'],0.1,-0.1)
# evaluate
sigs.PR(sigs.svm,true.sigs)

# no buy signals in this data...get NaN for precision
# and 0 for recall

# We note that SVM model does better than previous ANN in
# terms of precision, but with lower recall

# Here we model the signals as a classification task using
# kernlab
library(kernlab)
# append s, b, h recommendation as 1st column
# and remove the rownames column:
data <- cbind(signals=signals,Tdata.train[,-1])
# Use C (cost) parameter of ksvm() set to 10...different
# than last time, default value of C is 1
ksv <- ksvm(signals ~ .,data[1:1000,],C=10)
# We use automatic sigma estimation (implicit sigest())
# for RBF or laplace kernel
ks.preds <- predict(ksv,data[1001:2000,])
sigs.PR(ks.preds,data[1001:2000,1])

# Classification SVM task results not as interesting as
# regression SVM task results....precision is quite low

### Multivariate Adaptive Regression Splines (MARS)

# Are used in additive regression models, you have basis
# functions instead of coefficients. Most common basis
# functions are 'hinge' functions called because instead
# of a straight line, it 'bends' at an angle at some
# specific point (ie. looks like a hinge)...is in package
# mda as function mars() and in package earth as function
# earth() which we use for our regression task:

library(earth)
# use hinge function to predict
e <- earth(Tform,Tdata.train[1:1000,])
# predict:
e.preds <- predict(e,Tdata.train[1001:2000,])
# extract predicted signals:
sigs.e <- trading.signals(e.preds,0.1,-0.1)
# actual signals:
true.sigs <- trading.signals(Tdata.train[1001:2000,'T.ind.GSPC'],0.1,-0.1)
# evaluate
sigs.PR(sigs.e,true.sigs)

# Results are comparable to those obtained with SVMs for
# classification, with precision scores around 30% but
# with lower levels of recall

###################################################
### From Predictions into Actions
###################################################

# How are we going to use the signal predictions
# obtained by our modeling techniques earlier?

# That is, given a set of signals output by some
# model there may be many ways to use them to act
# on the market.

### How will predictions be used?

# We assume we are always trading in future markets.

# These markets are based on contracts to buy or sell 
# a commodity on a certain date in the future at the 
# price determined by the market at that future time.

# This means our trading system will be able to handle
# two types of trading positions: Long and Short.

# Long positions are opened by buying a commodity at 
# time t and price p, and selling it at a later time
# t + x. It makes sense for the trader to open such 
# positions when s/he expects that the price will rise 
# in the future. 

# On short positions, the trader sells the security at
# time t with price p with the obligation of buying it 
# in the future. These types of positions allows the
# trader to make profit when the prices decline as s/he
# will buy the security at a time later than t. 

# Or informally, we can say that we will open short 
# positions when we think prices will decline, and open 
# long positions when we believe the prices are going up.

# Given a set of signals, there are many ways to trade
# in future markets.

# Let's describe a few plausible trading strategies.

### First Strategy

# Decisions are made at the end of the trading day after
# knowing all daily quotes of current session. 

# If we think prices are falling:

# If models signal declining prices, and we have an open
# position (stocks held) we ignore the model. If we do
# not have an open position, we open a short position
# by issuing a sell order.

# When this order is carried out by the market at a price 
# pr sometime in the future, we will immediately post two 
# other orders. The first is a buy limit order with a
# limit price of pr-p%, where p% is a target profit margin.

# This type of order is carried out only if the market 
# price reaches the target limit price or below. This order 
# expresses what our target profit is for the short
# position just opened. We will wait 10 days for this 
# target to be reached. If the order is not carried out 
# by this deadline, we will buy at the closing price of
# the 10th day. The second order is a buy stop order with
# a price limit pr+l%. This order is placed with the goal 
# of limiting our eventual losses with this position.

# The order will be executed if the market reaches the 
# price pr+l%, thus limiting our possible losses to l%.

# If we think prices are rising:

# We consider opening a long position is we are currently
# out of the market (not holding stocks). We will post a
# buy order that will be accomplished at a time t and 
# a price pr. As before, at that time we will immediately 
# post two new orders.

# The first will be a sell limit order with a target price 
# of pr + p%, which will only be executed if the market 
# reaches a price of pr + p% or above. This sell
# limit order will have a deadline of 10 days, as before.

# The second order is a sell stop order with price pr-l%, 
# which will again limit our eventual losses to l%.

# First strategy is conservative in that it will only have
# a single position opened at any time. Moreover, after 
# 10 days of waiting for the target profit, the positions 
# are immediately closed. 

# So we also consider a more "risky" trading strategy. 
# This other strategy is similar to the previous one,
# except that we will always open new positions if there 
# are signals with that indication, and if we have 
# sufficient money for that.

# Moreover, we will wait forever for the positions to 
# reach either the target profit or the maximum allowed 
# loss.

# Only use these two strategies

# We will only consider these two main trading strategies
# with slight variations on the used parameters 
# (e.g., holding time, expected profit margin, or
# amount of money invested on each position).

# This section describes how to implement the ideas we 
# have sketched regarding trading with the signals of 
# our models. Our book package provides the function
# trading.simulator(), which can be used to put all 
# these ideas together by carrying out a trading simulation 
# with the signals of any model. The main parameters of
# this function are the market quotes for the simulation
# period and the model signals for this period. 

# Two other parameters are the name of the user-defined 
# trading policy function and its list of parameters. 

# Finally, we can also specify the cost of each 
# transaction and the initial capital available for
# the trader. The simulator will call the user-provided 
# trading policy function at the end of each daily 
# section, and the function should return the orders 
# that it wants the simulator to carry out. 

# The simulator carries out these orders on the market
# and records all activity in several data structures. 

# The result of the simulator is an object of class 
# tradeRecord containing the information of this
# simulation. This object can then be used in other 
# functions to obtain economic evaluation metrics or 
# graphs of the trading activity, as we will see.

# Before proceeding with an example of this type of 
# simulation, we provide further details on the trading 
# policy functions that the user needs to supply to the
# simulator. These functions should be written using 
# a certain protocol, that is, they should be aware 
# of how the simulator will call them, and they
# should return the information this simulator is 
# expecting.

# At the end of each daily session d, the simulator 
# calls the trading policy functions with four main
# arguments plus any other parameters the user has
# provided in the call to the simulator. 

# These four arguments are (1) a vector with the 
# predicted signals until day d, (2) the market quotes 
# (up to d), (3) the currently opened positions, 
# and (4) the money currently available to the trader.

# The current position is a matrix with as many rows
# as there are open positions at the end of day d. 
# This matrix has four columns: "pos.type" that
# can be 1 for a long position or -1 for a short 
# position; "N.stocks", which is the number of stocks 
# of the position; Odate", which is the day on which
# the position was opened (a number between 1 and d); 
# and "Oprice", which is the price at which the 
# position was opened. The row names of this matrix
# contain the IDs of the positions that are relevant
# when we want to indicate the simulator that a 
# certain position is to be closed.

# this information is provided by the simulator 
# to ensure the user can define a broad set of
# trading policy functions. The user-defined functions 
# should return a data frame with a set of orders 
# that the simulator should carry out.

# This data frame should include the following 
# information (columns): "order", which should be 
# 1 for buy orders and -1 for sell orders; 
# "order.type", which should be 1 for market orders 
# that are to be carried out immediately (the next day),
# 2 for limit orders or 3 for stop orders; "val",
# which should be the quantity of stocks to trade 
# for opening market orders, NA for closing market 
# orders, or a target price for limit and stop orders; 
# "action", which should be "open"for orders that 
# are opening a new position or "close" for orders
# closing an existing position; and finally, 
# "posID", which should contain the ID of the 
# position that is being closed, if applicable.

# Here is an illustration of a user-defined trading 
# policy function:



policy.1 <- function(signals,market,opened.pos,money,
                     bet=0.2,hold.time=10,
                     exp.prof=0.025, max.loss= 0.05
                     )
  {
    d <- NROW(market) # this is the ID of today
    orders <- NULL
    nOs <- NROW(opened.pos)
    # nothing to do!
    if (!nOs && signals[d] == 'h') return(orders)

    # First lets check if we can open new positions
    # i) long positions
    if (signals[d] == 'b' && !nOs) {
      quant <- round(bet*money/market[d,'Close'],0)
      if (quant > 0) 
        orders <- rbind(orders,
              data.frame(order=c(1,-1,-1),order.type=c(1,2,3), 
                         val = c(quant,
                                 market[d,'Close']*(1+exp.prof),
                                 market[d,'Close']*(1-max.loss)
                                ),
                         action = c('open','close','close'),
                         posID = c(NA,NA,NA)
                        )
                       )

    # ii) short positions  
    } else if (signals[d] == 's' && !nOs) {
      # this is the nr of stocks we already need to buy 
      # because of currently opened short positions
      need2buy <- sum(opened.pos[opened.pos[,'pos.type']==-1,
                                 "N.stocks"])*market[d,'Close']
      quant <- round(bet*(money-need2buy)/market[d,'Close'],0)
      if (quant > 0)
        orders <- rbind(orders,
              data.frame(order=c(-1,1,1),order.type=c(1,2,3), 
                         val = c(quant,
                                 market[d,'Close']*(1-exp.prof),
                                 market[d,'Close']*(1+max.loss)
                                ),
                         action = c('open','close','close'),
                         posID = c(NA,NA,NA)
                        )
                       )
    }
    
    # Now lets check if we need to close positions
    # because their holding time is over
    if (nOs) 
      for(i in 1:nOs) {
        if (d - opened.pos[i,'Odate'] >= hold.time)
          orders <- rbind(orders,
                data.frame(order=-opened.pos[i,'pos.type'],
                           order.type=1,
                           val = NA,
                           action = 'close',
                           posID = rownames(opened.pos)[i]
                          )
                         )
      }

    orders
  }

# This policy.1() function implements the first trading
# strategy we described. The function has four parameters
# that we can use to tune this strategy. These are the 

# bet parameter, which specifies the percentage of our
# current money, that we will invest each time we open 
# a new position; 

# the exp.prof parameter, which indicates the profit 
# margin we wish for our positions and is used when 
# posting the limit orders; 

# the max.loss, which indicates the maximum loss we 
# are willing to admit before we close the position, 
# and is used in stop orders; 

# and the hold.time parameter, which indicates the 
# number of days we are willing to wait to reach the 
# profit margin.

# If the holding time is reached without achieving 
# the wanted margin, the positions are closed.

# Notice that whenever we open a new position, we send 
# three orders back to the simulator: a market order 
# to open the position, a limit order to specify
# our target profit margin, and a stop order to 
# limit our losses.

# This function implements our second trading strategy:

policy.2 <- function(signals,market,opened.pos,money,
                     bet=0.2,exp.prof=0.025, max.loss= 0.05
                    )
  {
    d <- NROW(market) # this is the ID of today
    orders <- NULL
    nOs <- NROW(opened.pos)
    # nothing to do!
    if (!nOs && signals[d] == 'h') return(orders)

    # First lets check if we can open new positions
    # i) long positions
    if (signals[d] == 'b') {
      quant <- round(bet*money/market[d,'Close'],0)
      if (quant > 0) 
        orders <- rbind(orders,
              data.frame(order=c(1,-1,-1),order.type=c(1,2,3), 
                         val = c(quant,
                                 market[d,'Close']*(1+exp.prof),
                                 market[d,'Close']*(1-max.loss)
                                ),
                         action = c('open','close','close'),
                         posID = c(NA,NA,NA)
                        )
                       )

    # ii) short positions  
    } else if (signals[d] == 's') {
      # this is the money already committed to buy stocks
      # because of currently opened short positions
      need2buy <- sum(opened.pos[opened.pos[,'pos.type']==-1,
                                 "N.stocks"])*market[d,'Close']
      quant <- round(bet*(money-need2buy)/market[d,'Close'],0)
      if (quant > 0)
        orders <- rbind(orders,
              data.frame(order=c(-1,1,1),order.type=c(1,2,3), 
                         val = c(quant,
                                 market[d,'Close']*(1-exp.prof),
                                 market[d,'Close']*(1+max.loss)
                                ),
                         action = c('open','close','close'),
                         posID = c(NA,NA,NA)
                        )
                       )
    }

    orders
  }

# Number 2 function is similar to the first. The main
# difference lies in the fact that in this trading 
# policy we allow for more than one position to
# be opened at the same time, and also there is no 
# aging limit for closing the positions.

# Having defined the trading policy functions, we are 
# ready to try our trading simulator. 

# For illustration purposes we will select a small 
# sample of our data to obtain an SVM which is then
# used to obtain predictions for a subsequent period.

# We call our trading simulator with these predictions 
# to obtain the results of trading using the signals 
# of the SVM in the context of a certain trading policy.

# Train and test periods
start <- 1
len.tr <- 1000
len.ts <- 500
# train from 1 to 1,000:
tr <- start:(start+len.tr-1)
# test from 1,001 to 1,500
ts <- (start+len.tr):(start+len.tr+len.ts-1)

# getting the quotes for the testing period
data(GSPC)
date <- rownames(Tdata.train[start+len.tr,])
market <- GSPC[paste(date,'/',sep='')][1:len.ts]

# learning the model and obtaining its signal predictions
library(e1071)
s <- svm(Tform,Tdata.train[tr,],cost=10,gamma=0.01)
p <- predict(s,Tdata.train[ts,])
sig <- trading.signals(p,0.1,-0.1)

# now using the simulated trader
t1 <- trading.simulator(market,sig,
             'policy.1',list(exp.prof=0.05,
                             bet=0.2,hold.time=30))

# Please note that for this code to work, you have 
# to previously create the objects with the data for 
# modeling, using the previous instructions.

# In the call to the trading simulator we have selected 
# the first trading policy and have provided some different
# values for some of its parameters. We have used the
# default values for transaction costs (five monetary units)
# and for the initial capital (1 million monetary units). 

# The result of the call is an object of class
# tradeRecord. We can check its contents as follows:

t1 # first

# then
summary(t1)

# Then function tradingEvaluation() can be used to
# obtain a series of economic indicators of the
# performance during this simulation period:
tradingEvaluation(t1)

# We can obtain a graphical overview of the performance 
# of the trader using the function plot():
plot(t1,market,theme='white',name='SP500')

# The results of this trader are bad, with a negative return. 
# Would the scenario be different if we used the second 
# trading policy?

t2 <- trading.simulator(market,sig,'policy.2',list(exp.prof=0.05,bet=0.3))
summary(t2)

# We use function "tradingEvaluation()" for further 
# stats on this simulation.
tradingEvaluation(t2)

# Using the same signals but with a different trading 
# policy the return decreased from -1.06% to -4.16%. 

# We repeat the experiment with a different training 
# and testing period:
start <- 2000
len.tr <- 1000
len.ts <- 500
tr <- start:(start+len.tr-1)
ts <- (start+len.tr):(start+len.tr+len.ts-1)
s <- svm(Tform,Tdata.train[tr,],cost=10,gamma=0.01)
p <- predict(s,Tdata.train[ts,])
sig <- trading.signals(p,0.1,-0.1)
t2 <- trading.simulator(market,sig,'policy.2',list(exp.prof=0.05,bet=0.3))
summary(t2)

# We use function "tradingEvaluation()" for further stats:
tradingEvaluation(t2)

# This trader, obtained by the same modeling technique 
# and using the same trading strategy, obtained a 
# considerable worse result (-88.88% return). The 
# major lesson to be learned here is: get and use
# reliable statistical estimates. 

# Do not be fooled by a few repetitions of some experiments,
# even if it includes a 2-year testing period.

# We need more repetitions under different conditions to 
# ensure statistical reliability of our results. This is
# particularly true for time series models that have
# to handle different regimes (e.g., periods with rather 
# different volatility or trend).