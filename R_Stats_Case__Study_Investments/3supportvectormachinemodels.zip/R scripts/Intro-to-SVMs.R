#######################################
#####   SUPPORT VECTOR MACHINES   #####
#######################################

library("ROCR")
help(performance)

### Knowledge Representation

# Builds a linear model...identifies a line
# in 2 dimensions or a flat plane (in several)
# dimensions that separates observations with
# different values of the target variable.

# If that is successful, then we try to
# maximize the area between the two groups.

# Simple example, just two input variables
# Pressure3pm and Sunshine...also are 
# purposefully using cases that clearly
# separate whether it rains tomorrow or not
# (Yes, No in the legend):

library(rattle)
data(weather)
# rattle()
# being choosy about observations:
obs <- with(weather, Pressure3pm+Sunshine > 1032 | 
              (Pressure3pm+Sunshine < 1020 & 
                 RainTomorrow == "Yes"))
# are 366 observations in data
length(obs)
# but only 98 of them meet the 'OR' criteria
ds <- weather[obs,]
# plot whether it rains tomorrow or not:

with(ds, plot(ds$Pressure3pm, 
              ds$Sunshine, 
              pch=as.integer(RainTomorrow), 
              col=as.integer(RainTomorrow)+1))
# these lines are two possible linear models
# to separate yes's from no's, but there are
# an infinite number of such candidate lines:
lines(c(1016.2, 1019.6), c(0, 12.7))
lines(c(1032.8, 1001.5), c(0, 12.7))
legend("topleft", c("Yes", "No"), 
       pch=2:1, col=3:2)

# So, what we want is to find a line in the
# separating region so that we can make the
# line 'as thick as possible' separating the
# observations....we choose the line that fills
# up the maximum amount of space between the
# two regions.

# The observations that actually butt up
# against this region are the 'support vectors'

# same initial script as above
with(ds, plot(Pressure3pm, Sunshine, 
              pch=as.integer(RainTomorrow), 
              col=as.integer(RainTomorrow)+1))
# draw a 'maximally-filling' polygon:
polygon(c(1017.5, 1030, 1019, 1007.3), 
        c(-0.2, -0.2, 12.9, 12.9), 
        lty=0, col="grey")
# draw bisecting line:
lines(c(1017.2+(1030-1017.2)/2, 
        1007.3+(1019-1007.3)/2),c(-0.2, 12.9))
# draw legend
legend("topleft", c("Yes", "No"), 
       pch=2:1, col=3:2)

# This illustrates our ideal model, our goal
# using this approach of identifying support
# vectors between the classifications.

# This approach generalizes to multiple
# dimensions (many input variables) such that
# we search for hyperplanes that maximally
# fill the space between classes.

## Algorithm

# However, it is rarely the case that observa-
# tions are linearly separable

# This is actually generated from the data:

ds <- weather
with(ds, plot(Pressure3pm, Sunshine, 
              pch=as.integer(RainTomorrow), 
              col=as.integer(RainTomorrow)+1))
legend("topleft", c("Yes", "No"), 
       pch=2:1, col=3:2)

# So we draw on 'kernel' functions, that is,
# we introduce other derived variables obtained
# from the input variables, but combined and
# transformed in some nonlinear fashion.

# For example, we just add a variable that
# squares Pressure3pm and one that multiplies
# Pressure3pm by Sunshine to enhance separation:
?setdiff
ds <- weather
# square atmospheric pressure:
ds$p3sq <- ds$Pressure3pm^2
# multiply by sunshine:
ds$p3su <- ds$Pressure3pm*ds$Sunshine
keep <- 1:nrow(ds)
# we get rid of some to make our point:
keep <- setdiff(keep, which(ds$p3su < 4000 & 
                              ds$RainTomorrow == "No"))
# selectively trim back the set:
keep <- setdiff(keep, which(ds$p3su > 4000 & 
                              ds$p3su < 8000 &
                              ds$p3sq < 1030000 &
                              ds$RainTomorrow == "No"))
with(ds[keep,], plot(p3sq, p3su, 
                     pch=as.integer(RainTomorrow), 
                     col=as.integer(RainTomorrow)+1))
legend("topleft", c("Yes", "No"), pch=2:1, col=3:2)

# So we ended up with a nonlinear transformation.
# Kernel functions most often used are radial
# basis, linear, and polynomial functions.

# The radial basis kernel function is preferred.
# Once input variable space is transformed, we
# then proceed to build a linear model.

##### RATTLE TUTORIAL
rattle()
# Rattle builds SVMs with kernlab package
# which has an extensive collection of kernel
# functions to introduce new variables in data

# We use default radial kernel and weather
# dataset, are two parameters:

# C, penalty or cost, default is 1

# Options widget can then be used to set
# different values

#### WE GO TO RATTLE

### AND THEN BACK TO R

# Build the dataset object:

library(rattle)
weatherDS <- new.env()
?evalq
evalq({
  data <- weather
  nobs <- nrow(weather)
  target <- "RainTomorrow"
  # Get rid of 3 variables:
  vars <- -grep('^(Date|Location|RISK_)', names(data))
  set.seed(42)
  train <- sample(nobs, 0.7*nobs)
  form <- formula(RainTomorrow ~ .)
}, weatherDS)


# Build the boosted model with ksvm()
# from kernlab:

library(kernlab)
weatherSVM <- new.env(parent=weatherDS)
evalq({
  model <- ksvm(form, 
                data=data[train, vars],
                # use radial basis function:
                kernel="rbfdot",
                # model will predict probs
                # of outcomes:
                prob.model=TRUE)
}, weatherSVM)

# Obtain overview of model and print value

weatherSVM$model

##### Tuning parameters, part of kernlab

### Model Type

# type= in ksvm()
# Generally interested in classification
# tasks using C-svc formulation (support vector
# classification with a C parameter for tuning)

# Also have:

# nu-svc for automatically regularized support
# vector classification 

# one-svc for novelty detection

# eps-svr for support vector regression robust
# to small (epsilon) errors.

# nu-svr for support vector regression that
# automatically minimizes epsilon

### Kernel Function

# Kernel method maps our observations into a 
# higher dimensional space

# rfdot is radial basis
# polydot for polynomial kernel
# vanilladot for linear kernel
# splinedot for spline kernel

### Class Probabilities

# if prob.model=T then resulting model with
# calculate class probabilities

### Kernel Parameters:

# Cost of Constraints Violation C=

# C=1 is default. Larger values will consider
# more the points near the boundary, smaller 
# values relate to points further away from
# decision boundary

# However, typically C= argument has little
# impact on resulting model

# Sigma= (can adjust)

# works for radial basis function

# Cross Validation cross=

# Can specify an integer value to indicate
# whether to perform k-fold cross-validation
