###############################################
### Model Evaluation and Selection
###############################################

# load in previous cumulative worksession image
# included in the materials for this class.
# You need to do this so you have all of the
# objects that we have been building in the
# previous sessions available to you now.
# The file must be in the default directory 
# for the following command to work properly
# OR simply include the entire path name to 
# the file in your R script:
load(session-4-begin.RData)

# load cumulative libraries:
library ("DMwR")
library("xts")
library("tseries")
library("quantmod")
library("e1071")
library("kernlab")
library("earth")

# In this section we will consider how to obtain 
# reliable estimates of the selected evaluation
# criteria. These estimates will allow us to 
# properly compare and select among different 
# alternative trading systems.

#### Monte Carlo Simulation and Estimates

# Time series problems like this one bring 
# new challenges for obtaining reliable estimates 
# of our evaluation metrics. This is because
# all data observations have an attached time tag 
# that imposes an order among them. This ordering 
# generates the risk of obtaining unreliable
# estimates. In a previous case (algae blooms) we
# used the crossvalidation method to obtain reliable
# estimates of evaluation statistics. This
# includes a random re-sampling step that changes 
# the original ordering of the observations. 

# This means that cross-validation should not be
# applied to time series problems. Applying this 
# method could mean to test models on observations 
# that are older than the ones used to obtain them.

# So we cannot use this technique. So what do we do?

# Any estimation process using time series data 
# should ensure that the models are always tested 
# on data that is more recent than the data used 
# to obtain the models. So we cannot randomly resample
# which will change the time ordering. However, any
# proper estimation process should include some random 
# choices to ensure the statistical reliability of the 
# obtained estimates. 

# This involves repeating the estimation process 
# several times under different conditions, preferably 
# randomly selected. 

# Given a time series dataset spanning from time t
# to time t+N, how can we do this? First, we have to
# choose the train+test setup for which we want to get
# estimates. This means we must decide on the size of
# the train and test sets to be used in estimatiing. 

# The sum of these two sizes should be smaller than N
# to ensure that we are able to randomly generate
# different experimental scenarios with the data that 
# was provided to us. However, if we select a too small
# training size, we may seriously impair the performance
# of the models. Similarly, small test sets will also 
# be less reliable, particularly if we suspect there 
# are "regime shifts" in our problem and we wish
# to test the models under these circumstances.

# This dataset includes roughly 30 years of daily 
# quotes. We will evaluate the alternatives by 
# estimating their performance on a test set of 
# 5 years of quotes, when given 10 years of training data. 

# This ensures train and test sizes that are
# sufficiently large; and, moreover, it leaves space 
# for different repetitions of this testing process
# since we have 30 years of data.

# We will use a Monte Carlo experiment to obtain
# reliable estimates of our evaluation metrics. 

# Monte Carlo methods rely on random sampling to 
# obtain their results. We are going to use this
# sampling process to choose a set of R points 
# in our 30-year period of quotes.

# For each randomly selected time point r, 
# we will use the previous 10 years of quotes to 
# obtain the models and the subsequent 5 years to 
# test them. At the end of these R iterations 
# we will have R estimates for each of our
# evaluation metrics. Each of these estimates is 
# obtained on a randomly selected window of 15 years
# of data, the first 10 years used for training 
# and the remaining 5 years for testing. 

# This ensures that our experiments always respect
# the time ordering of the time series data. Repeating 
# the process R times will ensure sufficient variability 
# on the train+test conditions, which increases the
# reliability of our estimates. 

# Moreover, if we use the same set of R randomly
# selected points for evaluating different alternatives, 
# we can carry out paired comparisons to obtain 
# statistical confidence levels on the observed 
# differences of mean performance. 

# Notice that as we have to ensure that for every 
# random point r there are 10 years of data before 
# and 5 years after, this eliminates some of the data
# from the random selection of the R points. Since we
# have roughly 30 years of data altogether, we must
# begin to sample the random r time points at least
# 10 years into that 30-year range and must stop
# sampling 5 years before the end....so we have a
# 15 year total window to sample from.

# The function experimentalComparison(), which was 
# used with the algae blooms case for carrying out 
# k-fold cross-validation experiments, can also be 
# used for Monte Carlo experiments. W will use it 
# to obtain reliable estimates of the selected 
# evaluation metrics for alternative trading systems.

#### Experimental Comparisons

# Each of the alternative predictive models considered 
# on these experiments will be used in three different 
# model updating setups. These consist of (1) using a 
# single model for all 5-year testing periods, using 
# (2) a sliding window or (3) a growing window. 

# The DMwR package provides two functions that help 
# in the use of any model with these windowing schemes. 

# Functions slidingWindow() and growingWindow() 
# have five main arguments. The first is an object of 
# class learner that we have used before to hold the
# details on a learning system (function name and 
# parameter values).

# The second argument is the formula describing 
# the prediction task, and the 3rd and 4th arguments
# include the train and test datasets, respectively. 

# The 5th argument is the re-learning step to 
# use in the windowing schema. After the number
# of test cases is specified in this argument, 
# the model is re-relearned, either by sliding 
# or growing the training data used to obtain 
# the previous model. 

# Both functions return predictions of the model for the provided
# a test set using the respective windowing schema.

# The following code creates a set of functions 
# that will be used to carry out the full 
# train+test+evaluate cycle of the different 
# trading systems we will compare. We will 
# call these functions from within the Monte Carlo 
# routines for different train+test periods 
# on selected randomly chosen r time samples.

# Note there are 8 different functions below.

# The functions MC.x() obtain different models 
# using the provided formula and training set, 
# and then test them on the given test set, 
# returning the predictions.

# When appropriate, we have a version for the 
# regression task (name ending in "R") and 
# another for the classification tasks (name 
# ending in "C").

# Note that both these alternatives follow different
# pre- and post-processing steps to get to the 
# final result that is a set of predicted signals. 

# regression task:
MC.svmR <- function(form,train,test,b.t=0.1,s.t=-0.1,...) {
  require(e1071)
  t <- svm(form,train,...)
  p <- predict(t,test)
  trading.signals(p,b.t,s.t)
}

#classification task:
MC.svmC <- function(form,train,test,b.t=0.1,s.t=-0.1,...) {
  require(e1071)
  tgtName <- all.vars(form)[1]
  train[,tgtName] <- trading.signals(train[,tgtName],b.t,s.t)
  t <- svm(form,train,...)
  p <- predict(t,test)
  factor(p,levels=c('s','h','b'))
}

# regression task:
MC.nnetR <- function(form,train,test,b.t=0.1,s.t=-0.1,...) {
  require(nnet)
  t <- nnet(form,train,...)
  p <- predict(t,test)
  trading.signals(p,b.t,s.t)
}

# classification task:
MC.nnetC <- function(form,train,test,b.t=0.1,s.t=-0.1,...) {
  require(nnet)
  tgtName <- all.vars(form)[1]
  train[,tgtName] <- trading.signals(train[,tgtName],b.t,s.t)
  t <- nnet(form,train,...)
  p <- predict(t,test,type='class')
  factor(p,levels=c('s','h','b'))
}

MC.earth <- function(form,train,test,b.t=0.1,s.t=-0.1,...) {
  require(earth)
  t <- earth(form,train,...)
  p <- predict(t,test)
  trading.signals(p,b.t,s.t)
}

# These functions are called from the single(), 
# slide(), and grow() functions. These three
# functions obtain the predictions for the test 
# set using the model specified in the parameter 
# learner, using the respective model updating 
# mechanism.

singleModel <- function(form,train,test,learner,policy.func,...) {
  p <- do.call(paste('MC',learner,sep='.'),list(form,train,test,...))
  eval.stats(form,train,test,p,policy.func=policy.func)
}

slide <- function(form,train,test,learner,relearn.step,policy.func,...) {
  real.learner <- learner(paste('MC',learner,sep='.'),pars=list(...))
  p <- slidingWindowTest(real.learner,form,train,test,relearn.step)
  p <- factor(p,levels=1:3,labels=c('s','h','b'))
  eval.stats(form,train,test,p,policy.func=policy.func)
}

grow <- function(form,train,test,learner,relearn.step,policy.func,...) {
  real.learner <- learner(paste('MC',learner,sep='.'),pars=list(...))
  p <- growingWindowTest(real.learner,form,train,test,relearn.step)
  p <- factor(p,levels=1:3,labels=c('s','h','b'))
  eval.stats(form,train,test,p,policy.func=policy.func)
}

# After obtaining the predictions, these functions 
# collect the evaluation statistics we want to
# estimate with a call to the function eval.stats() 
# that is given below.

eval.stats <- function(form,train,test,preds,b.t=0.1,s.t=-0.1,...) {
  # Signals evaluation
  tgtName <- all.vars(form)[1]
  test[,tgtName] <- trading.signals(test[,tgtName],b.t,s.t)
  st <- sigs.PR(preds,test[,tgtName])
  dim(st) <- NULL
  names(st) <- paste(rep(c('prec','rec'),each=3),
                     c('s','b','sb'),sep='.')
  
  # Trading evaluation
  date <- rownames(test)[1]
  market <- GSPC[paste(date,"/",sep='')][1:length(preds),]
  trade.res <- trading.simulator(market,preds,...)

  c(st,tradingEvaluation(trade.res))
}

# The function eval.stats() uses two other functions
# to collect the precision and recall of the 
# signals, and several economic evaluation metrics. 

# Function sigs.PR() receives as arguments the 
# predicted and true signals, and calculates 
# precision and recall for the sell, buy, and 
# sell+buy signals. 

# The other function is tradingEvaluation(), 
# which obtains the economic metrics of a given 
# trading record. This trading record is obtained 
# with the function trading.simulator(), which 
# can be used to simulate acting on the market
# with the model signals. 

# The functions single(), slide(), and grow() 
# are called from the Monte Carlo routines with 
# the proper parameters filled in so that we 
# obtain the models we want to compare. 

# Below we describe how to set up a loop that
# goes over a set of alternative trading systems 
# and calls these functions to obtain estimates
# of their performance. Each trading system is 
# formed by some learning model with some specific
# learning parameters, plus a trading strategy
# that specifies how the model predictions are 
# used for trading. 

# We will consider three variants that derive from 
# the two policies policy.1() and policy.2(). The
# following functions implement these three variants:

pol1 <- function(signals,market,op,money)
  policy.1(signals,market,op,money,
           bet=0.2,exp.prof=0.025,max.loss=0.05,hold.time=10)

pol2 <- function(signals,market,op,money)
  policy.1(signals,market,op,money,
           bet=0.2,exp.prof=0.05,max.loss=0.05,hold.time=20)

pol3 <- function(signals,market,op,money)
  policy.2(signals,market,op,money,
           bet=0.5,exp.prof=0.05,max.loss=0.05)

# The following code runs the Monte Carlo experiments. 
# We recommend that you think twice before running 
# this code. Even on rather fast computers, it will
# take several days to complete. On the book Web page 
# Torgo provide the objects resulting from running 
# the experiments so that you can replicate the
# subsequent result analysis, without having to 
# run these experiments on your computer.

# The list of learners we will use
TODO <- c('svmR','svmC','earth','nnetR','nnetC')

# The data sets used in the comparison
DSs <- list(dataset(Tform,Tdata.train,'SP500'))

# Monte Carlo (MC) settings used.
# The MCsetts object controls the general parameters 
# of the experiment that specify the number of 
# repetitions (20), the size of the training sets 
# (2,540 over 10 years), the size of the test 
# sets (1,270 over 5 years), and the random number
# generator seed to use.
MCsetts <- mcSettings(20,     # 20 repetitions of the MC exps
                      2540,   # ~ 10 years for training
                      1270,   # ~ 5 years for testing
                      1234)   # random number generator seed

# Variants to try for all learners.

# The VARS list contains all parameter variants 
# we want to try for each learner. The variants 
# consist of all possible combinations of the 
# values we indicate for the parameters in the list. 

# Each of these variants will then be run
# in three different model updating "modes": single, 
# sliding window, and growing window. Also, we will 
# try for the two latter modes two re-learn steps: 
# 60 days and 120 days.

VARS <- list()
VARS$svmR   <- list(cost=c(10,150),gamma=c(0.01,0.001),
                    policy.func=c('pol1','pol2','pol3'))
VARS$svmC   <- list(cost=c(10,150),gamma=c(0.01,0.001),
                    policy.func=c('pol1','pol2','pol3'))
VARS$earth <- list(nk=c(10,17),degree=c(1,2),thresh=c(0.01,0.001),
                   policy.func=c('pol1','pol2','pol3'))
VARS$nnetR  <- list(linout=T,maxit=750,size=c(5,10),
                    decay=c(0.001,0.01),
                    policy.func=c('pol1','pol2','pol3'))
VARS$nnetC  <- list(maxit=750,size=c(5,10),decay=c(0.001,0.01),
                    policy.func=c('pol1','pol2','pol3'))

# For the svm models we tried four learning parameter 
# variants together with three different trading policies, 
# that is, 12 variants. For earth we tried 24 variants
# and for nnet another 12. Each of these variants were 
# tried in single mode and on the four windowing schemes 
# (two strategies with two different re-learn steps). 

# This obviously results in a lot of experiments being 
# carried out. There will be 60 (= 12 + 24 + 24) svm variants,
# 120 (= 24 + 48 + 48) earth variants, and 60 nnet variants. 
# Each of them will be executed 20 times with a training
# set of 10 years and a test set of 5 years. This is why it
# would take days to run the experiments on your computer.

###################################################
#### NOTE: STOP HERE, load objects manually below
###################################################

# main loop
for(td in TODO) {
  assign(td,
         experimentalComparison(
           DSs,         
           c(
             do.call('variants',
                     c(list('singleModel',learner=td),VARS[[td]],
                       varsRootName=paste('single',td,sep='.'))),
             do.call('variants',
                     c(list('slide',learner=td,
                            relearn.step=c(60,120)),
                       VARS[[td]],
                       varsRootName=paste('slide',td,sep='.'))),
             do.call('variants',
                     c(list('grow',learner=td,
                            relearn.step=c(60,120)),
                       VARS[[td]],
                       varsRootName=paste('grow',td,sep='.')))
             ),
            MCsetts)
         )

  # save the results
  save(list=td,file=paste(td,'Rdata',sep='.'))
}

###################################################
#### NOTE: START HERE, load objects manually
###################################################

#### Results Analysis

# (must be in default directory to work).
# can also load through RStudio menu (recommended)
load('svmR.Rdata')
load('svmC.Rdata')
load('earth.Rdata')
load('nnetR.Rdata')
load('nnetC.Rdata')

# or can just load workspace labelled:
# "session-4-at-results-analysis.RData"

# For each trading system variant, we have measured 
# several statistics of performance. Some are related 
# to the performance in terms of predicting the
# correct signals, while others are related to the 
# economic performance when using these signals to 
# trade. Deciding which are the best models according
# to our experiments involves a balance between 
# all these scores. The selected model(s) may vary 
# depending on which criteria we value the most.

# Despite the diversity of evaluation scores we can 
# still identify some of them as more relevant. 

# Among the signal prediction statistics, precision
# is more important than recall for this application. 
# In effect, precision has to do with the predicted 
# signals, and these drive the trading activity as
# they are the causes for opening positions. Low 
# precision scores are caused by wrong signals, which 
# means opening positions at the wrong timings. This
# will most surely lead to high losses. Recall does 
# not have this cost potential.

# Recall measures the ability of the models to capture
# trading opportunities. If the recall score is low, it 
# means lost opportunities, but not high costs. In this
# context, we will be particularly interested in the 
# scores of the models for the statistic "prec.sb", 
# which measures the precision of the buy and sell signals.

# In terms of trading performance, the return of the 
# systems is important (statistic "Ret"in our experiments), 
# as well as the return over the buy and hold strategy
# ("\"RetOverBH" in our experiments). Also important 
# is the percentage of profitable trades, which should 
# be clearly above 50% (statistic "PercProf").

# In terms of risk analysis, it is relevant to look at
# both the value of the Sharpe ratio and the Maximum 
# Draw-Down ("MaxDD").

# The function summary() can be applied to our loaded 
# compExp objects. However, given the number of variants 
# and performance statistics, the output can be over-
# whelming in this case.

# An alternative is to use the function rankSystems()
# provided by our package. With this function we can 
# obtain a top chart for the evaluation statistics
# in which we are interested, indicating the best models 
# and their scores:

tgtStats <- c('prec.sb','Ret','PercProf',
              'MaxDD','SharpeRatio')
allSysRes <- join(subset(svmR,stats=tgtStats),
                  subset(svmC,stats=tgtStats),
                  subset(nnetR,stats=tgtStats),
                  subset(nnetC,stats=tgtStats),
                  subset(earth,stats=tgtStats),
                  by = 'variants')
rankSystems(allSysRes,5,maxs=c(T,T,T,F,T))

# The function subset() can be applied to compExps 
# objects to select a part of the information stored
# stored in these objects. In this case we are selecting
# only a subset of the estimated statistics. Then we 
# put all trading variants together in a single compExp 
# object, using the function join(). This function
# can join compExp objects along different dimensions. 

# In this case it makes sense to join then by system 
# variants, as all other experimental conditions
# are the same. 

# Finally, we use the function rankSystems() to obtain 
# the top five scores among all trading systems for the 
# statistics we have selected. The notion of best score
# varies with each metric. Sometimes we want the largest
# values, while for others we want the lowest values. 

# This can be set up by the parameter maxs of function 
# rankSystems(), which lets you specify the statistics
# that are to be maximized.

# The first thing we notice when looking at these top 
# five results is that all of them involve either the 
# svm or nnet algorithm. 

# Another noticeable pattern is that almost all these
# variants use some windowing mechanism. This provides
# some evidence of the advantages of these alternatives
# over the single model approaches, which can be regarded
# as a confirmation of regime change effects on these data.


# We can also observe several remarkable (and suspicious)
# scores, namely in terms of the precision of the buy/sell
# signals. Obtaining 100% precision seems strange. A closer
# inspection of the results of these systems will
# reveal that this score is achieved by a very small 
# number of signals during the 5-year testing period,

summary(subset(svmC,
               stats=c('Ret','RetOverBH','PercProf','NTrades'),
               vars=c('slide.svmC.v5','slide.svmC.v6')))

# In effect, at most these methods made a single trade over
# the testing period with an average return of 0.25%, 
# which is -77.1% below the naive buy and hold strategy.


# These are clearly useless models.

# A final remark on the global rankings is that the results
# in terms of maximum draw-down cannot be considered as 
# too bad, while the Sharpe ratio scores are certainly
# disappointing.

# To reach some conclusions on the value of all these 
# variants, we need to add some constraints on some of
# the statistics. Let us assume the following minimal values:

# We want (1) a reasonable number of average trades,
# say more than 20; (2) an average return that should at 
# least be greater than 0.5% (given the generally low 
# scores of these systems); (3) and also a percentage
# of profitable trades higher than 40%. We will now see 
# if there are some trading systems that meet these constraints.

fullResults <- join(svmR,svmC,earth,nnetC,nnetR,by='variants')
nt <- statScores(fullResults,'NTrades')[[1]]
rt <- statScores(fullResults,'Ret')[[1]]
pp <- statScores(fullResults,'PercProf')[[1]]
s1 <- names(nt)[which(nt > 20)]
s2 <- names(rt)[which(rt > 0.5)]
s3 <- names(pp)[which(pp > 40)]
namesBest <- intersect(intersect(s1,s2),s3)

# note that book script uses summary() here, not compAnalysis:
summary(subset(fullResults,
                    stats=tgtStats,
                    vars=namesBest))

# In order to obtain the names of the trading variants
# satisfying the constraints, we have used the statScores()
# function available in our package.

# This function receives a compExp object and the name of 
# a statistic and, by default, provides the average scores
# of all systems on this statistic. The result is a list
# with as many components as there are datasets in the 
# experiments (in our case, this is a single dataset). 

# The user can specify a function on the third optional
# argument to obtain another numeric summary instead of 
# the average. Using the results of this function, we 
# have obtained the names of the variants satisfying 
# each of the constraints. We finally obtained the names
# of the variants that satisfy all constraints using 
# the intersect() function, which obtains the intersection
# between sets of values.

# As we can see, only three of the 240 trading variants
# that were compared satisfy these minimal constraints.
# All of them use a regression task and all are based
# on neural networks. 

# The three use the training data differntly. The 
# "single.nnetR.v12" method does not use any windowing
# schema and achieves an impressive 97.4% average
# return. However, if we look more closely at the
# results of this system, we see that at the same 
# time on one of the iterations it achieved a return 
# of -160.4%. This is clearly a system with a rather 
# marked instability of the results obtained, as we 
# can confirm by the standard deviation of the return
# (650.86%). The other two systems achieve rather 
# similar scores.

# The following code carries out a statistical 
# significance analysis of the results using the
# function compAnalysis():

compAnalysis(subset(fullResults,
                    stats=tgtStats,
                    vars=namesBest))

# Note that the above code can generate some 
# warnings caused because some systems do not obtain
# a valid score on some of the statistics (for
# example no buy or sell signals lead to invalid 
# precision scores).

# Despite the variability of the results, the above
# Wilcoxon significance test tells us that the average
# return of "single.nnetR.v12"is higher than those of 
# the other systems with 95% confidence. 

# Yet, with respect to the other statistics, this variant
# is clearly worse.

# We may have a better idea of the distribution of the
# scores on some of these statistics across all 20 
# repetitions by plotting the compExp object:

plot(subset(fullResults,
            stats=c('Ret','PercProf','MaxDD'),
            vars=namesBest))

# The scores of the two systems using windowing schemas
# are very similar, making it difficult to distinguish
# among them. On the contrary, the results of
# "single.nnetR.v12" are clearly distinct. We can 
# observe that the high average return is achieved thanks
# to a clearly abnormal (around 2800%) return in one
# of the iterations of the Monte Carlo experiment. 

# The remainder of the scores for this system seem 
# clearly inferior to the scores of the other two. 
# We can check the configuration of this particular
# trading system using the function getVariant():

getVariant('single.nnetR.v12',nnetR)

# It uses the trading policy "pol3" and learns a neural
# network with ten hidden units with a learning decay
# rate of 0.01.

# In summary, given these results, if we were to select
# any of the considered alternatives, we would probably
# skip the "single.nnetR.v12", given its instability.

# In the next section we will apply our three best trading
# systems on the final 9 years of data that were left
# out for the final evaluation of the best systems.



###################################################
### The Trading System
###################################################
data <- tail(Tdata.train,2540)
results <- list()
for(name in namesBest) {
  sys <- getVariant(name,fullResults)
  results[[name]] <- runLearner(sys,Tform,data,Tdata.eval)
}
results <- t(as.data.frame(results))




results[,c('Ret','RetOverBH','MaxDD','SharpeRatio','NTrades','PercProf')]


getVariant('grow.nnetR.v12',fullResults)


model <- learner('MC.nnetR',list(maxit=750,linout=T,trace=F,size=10,decay=0.001))
preds <- growingWindowTest(model,Tform,data,Tdata.eval,relearn.step=120)
signals <- factor(preds,levels=1:3,labels=c('s','h','b'))
date <- rownames(Tdata.eval)[1]
market <- GSPC[paste(date,"/",sep='')][1:length(signals),]
trade.res <- trading.simulator(market,signals,policy.func='pol2')


plot(trade.res,market,theme='white',name='SP500 - final test')


library(PerformanceAnalytics)
rets <- Return.calculate(trade.res@trading$Equity)


chart.CumReturns(rets,main='Cumulative returns of the strategy',ylab='returns')


yearlyReturn(trade.res@trading$Equity)


plot(100*yearlyReturn(trade.res@trading$Equity),
     main='Yearly percentage returns of the trading system')
abline(h=0,lty=2)


table.CalendarReturns(rets)


table.DownsideRisk(rets)


